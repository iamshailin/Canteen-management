package com.example.readdata;

public class OrderList {
    private String Order;

    public OrderList() {
    }

    public OrderList(String order) {
        Order = order;
    }

    public String getOrder() {
        return Order;
    }

    public void setOrder(String order) {
        Order = order;
    }
}
